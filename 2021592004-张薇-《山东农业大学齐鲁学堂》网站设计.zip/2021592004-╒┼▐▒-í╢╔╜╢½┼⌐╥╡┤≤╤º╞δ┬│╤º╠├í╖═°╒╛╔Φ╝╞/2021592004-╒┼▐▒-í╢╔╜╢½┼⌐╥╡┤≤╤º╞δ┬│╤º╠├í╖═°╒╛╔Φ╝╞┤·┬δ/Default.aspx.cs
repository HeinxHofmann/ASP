﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class _Default : System.Web.UI.Page
{
    dataOperate mydo = new dataOperate();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bindtorrepeater1();
            bindtorrepeater2();
            bindtorrepeater3();
            bindtorrepeater4();
            bindtorrepeater5();
            bindtorrepeater6();
            bindtorrepeater7();
        }

    }
    protected void bindtorrepeater1()
    {
        string sql = "select top 4 * from messagess where column2_id=1 order by messagess_datetime desc ";
        Repeater1.DataSource = mydo.rows(sql, "dt").DefaultView;
        Repeater1.DataBind();
    }
    protected void bindtorrepeater2()
    {
        string sql = "select top 4 * from messagess where column2_id=10 order by messagess_datetime desc ";
        Repeater2.DataSource = mydo.rows(sql, "xx").DefaultView;
        Repeater2.DataBind();
    }
    protected void bindtorrepeater3()
    {
        string sql = "select top 6 * from messagess where column2_id=4 order by messagess_datetime desc ";
        Repeater3.DataSource = mydo.rows(sql, "heinz").DefaultView;
        Repeater3.DataBind();
    }
    protected void bindtorrepeater4()
    {
        string sql = "select top 6 * from messagess where column2_id=6 order by messagess_datetime desc ";
        Repeater4.DataSource = mydo.rows(sql, "holman").DefaultView;
        Repeater4.DataBind();
    }
    protected void bindtorrepeater5()
    {
        string sql = "select top 2 * from messagess where column2_id=8 order by messagess_datetime desc ";
        Repeater5.DataSource = mydo.rows(sql, "yt").DefaultView;
        Repeater5.DataBind();
    }
    protected void bindtorrepeater6()
    {
        string sql = "select top 6 * from messagess where column2_id=12 order by messagess_datetime desc ";
        Repeater6.DataSource = mydo.rows(sql, "mj").DefaultView;
        Repeater6.DataBind();
    }
    protected void bindtorrepeater7()
    {
        string sql = "select top 1 * from messagess where column2_id=2 order by messagess_datetime desc ";
        Repeater7.DataSource = mydo.rows(sql, "bm").DefaultView;
        Repeater7.DataBind();
    }
    protected string getString(string StringInput, int StringLength)
    {
        if (StringInput == " " || StringInput == null)
            return " ";
        string tempTitle = " ";
        if (StringInput.Length > StringLength)
            tempTitle = StringInput.Substring(0, StringLength) + "... ";
        else if (StringInput.Length == StringLength)
            tempTitle = StringInput;
        else
        {
            for (int i = 0; i < StringLength - StringInput.Length; i++)
            {
                StringInput = StringInput + "  ";
                tempTitle = StringInput;
            }
        }
        return tempTitle;
    }
}