﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class admin_user_add : System.Web.UI.Page
{
    dataOperate mydo = new dataOperate();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string sql = "insert into admin values('" + TextBox1.Text + "','" + TextBox2.Text + "')";
        if (TextBox2.Text == TextBox3.Text)
        {
            if (mydo.add_delete_update(sql))
            {
                Response.Write("<script>alert('添加成功')</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('新密码与确认密码不一致')</script>");
        }
    }
}