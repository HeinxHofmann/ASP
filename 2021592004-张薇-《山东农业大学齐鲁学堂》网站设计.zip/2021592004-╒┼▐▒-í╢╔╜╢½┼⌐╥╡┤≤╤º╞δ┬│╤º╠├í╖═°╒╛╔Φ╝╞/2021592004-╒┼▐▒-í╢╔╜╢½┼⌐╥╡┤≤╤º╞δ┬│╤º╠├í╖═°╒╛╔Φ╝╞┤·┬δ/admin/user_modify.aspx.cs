﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;


public partial class admin_user_modify : System.Web.UI.Page
{
    dataOperate mydo = new dataOperate();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] != null)
        {
            TextBox1.Text = Session["username"].ToString();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string sql = "update admin set pwd11='" + TextBox2.Text + "'where username='" + TextBox1.Text + "'";
        if (TextBox2.Text == TextBox3.Text)
        {
            if (mydo.add_delete_update(sql))
                Response.Write("<script>alert('修改成功')</script>");

        }
        else
        {
            Response.Write("<script>alert('新密码与确认密码不一致')<script>");
        }
    }
}