﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_user_admin : System.Web.UI.Page
{
    dataOperate mydo = new dataOperate();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bindtogridview1();
        }
    }
    protected void bindtogridview1()
    {
        string sql = "select * from admin";
        GridView1.DataSource = mydo.rows(sql, "t55").DefaultView;
        GridView1.DataBind();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string sql = "delete from admin where username='" + GridView1.DataKeys[e.RowIndex].Value + "'";
        if (mydo.add_delete_update(sql))
        {
            Response.Write("<script>alert('删除成功');window.location.href='user_delete.aspx'</script>");
        }
    }
}