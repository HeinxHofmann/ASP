﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class 列表页 : System.Web.UI.Page
{
    dataOperate mydo = new dataOperate();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bindtorepeater1();
            bindtorepeater2();
        }
    }
    protected void bindtorepeater1()
    {
        string id = Request.QueryString["column1_id"].ToString();
        string sql = "select * from columnss where column1_id=" + id;

        Repeater1.DataSource = mydo.rows(sql, "kk").DefaultView;
        Repeater1.DataBind();

        if (id == "1")
        {
            Label1.Text = "学院概况";
            Label2.Text = "学院概况";
        }
        else if (id == "2")
        {
            Label1.Text = "人才培养";
            Label2.Text = "人才培养";
        }
        else if (id == "3")
        {
            Label1.Text = "党团工作";
            Label2.Text = "党团工作";
        }
        else if (id == "4")
        {
            Label1.Text = "合作交流";
            Label2.Text = "合作交流";
        }
        else if (id == "5")
        {
            Label1.Text = "学术文化";
            Label2.Text = "学术文化";
        }
        else if (id == "6")
        {
            Label1.Text = "招生就业";
            Label2.Text = "招生就业";
        }
    }
    protected void bindtorepeater2()
    {
        string id = Request.QueryString["column1_id"].ToString();
        string sql = "select top 8 * from messagess where column1_id=" + id + " order by messagess_datetime desc";
        PagedDataSource ps = new PagedDataSource();//实例化,实现分页
        ps.DataSource = mydo.rows(sql, "ypi").DefaultView;
        ps.AllowPaging = true;//允许分页
        ps.PageSize = 15;//每页显示行数
        ps.CurrentPageIndex = Convert.ToInt32(Label3.Text) - 1;//当前页的索引号=当前页码-1，注意数据类型转换
        Label4.Text = Convert.ToString(ps.PageCount);//总页码
        LinkButton1.Enabled = true;
        LinkButton2.Enabled = true;
        LinkButton3.Enabled = true;
        LinkButton4.Enabled = true;
        if (Label3.Text == "1")//若是第一页，前两个按钮不能用
        {
            LinkButton1.Enabled = false;
            LinkButton2.Enabled = false;
        }
        if (Label3.Text == Label4.Text)//若是最后一页，后两个按钮不能用
        {
            LinkButton3.Enabled = false;
            LinkButton4.Enabled = false;
        }

        Repeater2.DataSource = ps;
        Repeater2.DataBind();
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {//第一页,使当前页码=1
        Label3.Text = "1";
        bindtorepeater2();
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {//最后一页,使当前页码=总页码
        Label3.Text = Label4.Text;
        bindtorepeater2();
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {//上一页,使当前页码减1
        Label3.Text = (Convert.ToInt32(Label3.Text) - 1).ToString();
        bindtorepeater2();
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {//下一页,使当前页码加1
        Label3.Text = (Convert.ToInt32(Label3.Text) + 1).ToString();
        bindtorepeater2();
    }
   
}