﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class 详细页 : System.Web.UI.Page
{
    dataOperate mydo = new dataOperate();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bindtorepeater1();
            bindtorepeater2();
        }
    }
    protected void bindtorepeater1()
    {

        string id = string.Empty;
        string id2 = string.Empty;

        if (Request.QueryString["column1_id"] != null)
        {
            id = Request.QueryString["column1_id"].ToString();
        }

        if (Request.QueryString["column2_id"] != null)
        {
            id2 = Request.QueryString["column2_id"].ToString();
        }


        string sql = "select * from columnss where column1_id=" + id;
        Repeater1.DataSource = mydo.rows(sql, "kk").DefaultView;
        Repeater1.DataBind();

        if (id == "1" && id2 == "1")
        {
            Label1.Text = "学院概况";
            Label2.Text = "学院简介";
        }
        else if (id == "1" && id2 == "2")
        {
            Label1.Text = "学院概况";
            Label2.Text = "机构设置";
        }
        else if (id == "1" && id2 == "3")
        {
            Label1.Text = "学院概况";
            Label2.Text = "师资队伍";
        }
        else if (id == "2" && id2 == "4")
        {
            Label1.Text = "人才培养";
            Label2.Text = "培养方案";
        }
        else if (id == "2" && id2 == "5")
        {
            Label1.Text = "人才培养";
            Label2.Text = "培养特色";
        }
        else if (id == "3" && id2 == "6")
        {
            Label1.Text = "党团工作";
            Label2.Text = "党建工作";
        }
        else if (id == "3" && id2 == "7")
        {
            Label1.Text = "党团工作";
            Label2.Text = "学生工作";
        }
        else if (id == "4" && id2 == "8")
        {
            Label1.Text = "合作交流";
            Label2.Text = "合作项目";
        }
        else if (id == "4" && id2 == "9")
        {
            Label1.Text = "合作交流";
            Label2.Text = "合作动态";
        }
        else if (id == "5" && id2 == "10")
        {
            Label1.Text = "学术文化";
            Label2.Text = "学术交流";
        }
        else if (id == "5" && id2 == "11")
        {
            Label1.Text = "学术文化";
            Label2.Text = "学术沙龙";
        }
        else if (id == "6" && id2 == "12")
        {
            Label1.Text = "招生就业";
            Label2.Text = "招生信息";
        }
        else if (id == "6" && id2 == "13")
        {
            Label1.Text = "招生就业";
            Label2.Text = "就业动态";
        }
    }
    protected void bindtorepeater2()
    {
        string id = Request.QueryString["messagess_id"];
        if (!string.IsNullOrEmpty(id))
        {
            string sql = "select * from messagess where messagess_id= " + id + " order by messagess_datetime desc ";


            Repeater2.DataSource = mydo.rows(sql, "yp99m").DefaultView;
            Repeater2.DataBind();
        }
        else
        {
            // 处理参数为空的情况
        }


    }
}