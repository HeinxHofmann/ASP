﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
public partial class details : System.Web.UI.Page
{
    Data dt = new Data();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
           
            bindtorepeater2();



        }
    }
    
    protected void bindtorepeater2()
    {
        string id = Request.QueryString["notice_id"].ToString();
        string sql = "select * from noticess where notice_id=" + id + " order by notice_datetime desc";
        Repeater2.DataSource = dt.rows(sql, "kkk11").DefaultView;
        Repeater2.DataBind();
    }


}