﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb; 
public partial class list1t : System.Web.UI.Page
{       Data dt = new Data();
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bindtorepeater1();
            bindtorepeater2();
           


        }
    }
    protected void bindtorepeater1()
    {
        string id = Request.QueryString["column1_id"].ToString();
        string id2 = Request.QueryString["column2_id"].ToString();

        string sql = "select * from columnss where column1_id=" + id;
        Repeater1.DataSource = dt.rows(sql, "kkk").DefaultView;
        Repeater1.DataBind();
        if (id == "1" && id2 == "1")
        {
            Label1.Text = "学院概况";
            Label2.Text = "学院动态";

        }
        else if (id == "1" &&id2 == "2")
        {
            Label1.Text = "学院概况";
            Label2.Text = "院系介绍";

        }
        else if (id == "1" && id2 == "3")
        {
            Label1.Text = "学院概况";
            Label2.Text = "院务公开";

        }
        else if (id == "2" && id2 == "4")
        {
            Label1.Text = "师资队伍";
            Label2.Text = "教学团队";

        }
        else if (id == "2" && id2 == "5")
        {
            Label1.Text = "师资队伍";
            Label2.Text = "计算机系";

        }
        else if (id == "2" && id2 == "6")
        {
            Label1.Text = "师资队伍";
            Label2.Text = "信息工程系";

        }
        else if (id == "3" && id2 == "7")
        {
            Label1.Text = "教学工作";
            Label2.Text = "教学动态";

        }
        else if (id == "3" && id2 == "8")
        {
            Label1.Text = "教学工作";
            Label2.Text = "科技专业";

        }
        else if (id == "3" && id2 == "9")
        {
            Label1.Text = "教学工作";
            Label2.Text = "网络专业 ";

        }
        else if (id == "4" && id2 == "10")
        {
            Label1.Text = "学团工作";
            Label2.Text = "学生组织";

        }
        else if (id == "4" && id2 == "11")
        {
            Label1.Text = "学团工作";
            Label2.Text = "学生社团";

        }
        else if (id == "4" && id2 == "12")
        {
            Label1.Text = "学团工作";
            Label2.Text = "学团活动";

        }
        else if (id == "5" && id2 == "13")
        {
            Label1.Text = "招生就业";
            Label2.Text = "招生工作";

        }
        else if (id == "5" && id2 == "14")
        {
            Label1.Text = "招生就业";
            Label2.Text = "就业信息";

        }
    }
    protected void bindtorepeater2()
    {
        string id = Request.QueryString["column2_id"].ToString();
        string sql = "select * from messagess where column2_id=" + id +" order by messagess_datetime desc";
        PagedDataSource psd = new PagedDataSource();
        psd.DataSource = dt.rows(sql, "ttt").DefaultView;
        psd.PageSize = 16;
        psd.AllowPaging = true;
        psd.CurrentPageIndex = Convert.ToInt32(Label3.Text) - 1;
        Label4.Text = psd.PageCount.ToString();
        LinkButton1.Enabled = true;
        LinkButton2.Enabled = true;
        LinkButton3.Enabled = true;
        LinkButton4.Enabled = true;
        if (Label3.Text == "1")
        {
            LinkButton1.Enabled = false;
            LinkButton2.Enabled = false;
        }
        if (Label3.Text == Label4.Text)
        {
            LinkButton3.Enabled = false;
            LinkButton4.Enabled = false;
        }

           Repeater2.DataSource = psd;
           Repeater2.DataBind();


        
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Label3.Text = "1";
        bindtorepeater2();
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Label3.Text = Convert.ToString(Convert.ToInt32(Label3.Text)-1);
        bindtorepeater2();
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Label3.Text = Convert.ToString(Convert.ToInt32(Label3.Text) + 1);
        bindtorepeater2();
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Label3.Text = Label4.Text;
        bindtorepeater2();
    }
}