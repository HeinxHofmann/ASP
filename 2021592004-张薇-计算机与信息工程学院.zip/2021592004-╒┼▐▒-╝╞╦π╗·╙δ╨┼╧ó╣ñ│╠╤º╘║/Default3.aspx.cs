﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
public partial class Default3 : System.Web.UI.Page
{
    Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bindtorepeater1();
            bindtorepeater2();
            bindtorepeater3();
            bindtorepeater4();
        
        
        }

    }
    protected void bindtorepeater1()
    {
        string sql = "select top 8 * from messagess where column2_id=1 order by messagess_datetime desc";
        Repeater1.DataSource = dt.rows(sql, "one").DefaultView;
        Repeater1.DataBind();
    }
    protected void bindtorepeater2()
    {
        string sql = "select top 8 * from messagess where column1_id=4 order by messagess_datetime desc";
        Repeater2.DataSource = dt.rows(sql,"two").DefaultView;
        Repeater2.DataBind();
    }
    protected void bindtorepeater3()
    {
        string sql = "select top 8 * from messagess where column2_id=14 order by messagess_datetime desc";
        Repeater3.DataSource = dt.rows(sql,"three").DefaultView;
        Repeater3.DataBind();
    }
    protected void bindtorepeater4()
    {
        string sql = "select top 8 * from noticess where notice_id order by notice_datetime desc";
        Repeater4.DataSource = dt.rows(sql, "four").DefaultView;
        Repeater4.DataBind();
    }
    protected string getString(string StringInput, int StringLength)
    {
        if (StringInput == " " || StringInput == null)
            return " ";
        string tempTitle = " ";
        if (StringInput.Length > StringLength)
            tempTitle = StringInput.Substring(0, StringLength) + "... ";
        else if (StringInput.Length == StringLength)
            tempTitle = StringInput;
        else
        {
            for (int i = 0; i < StringLength - StringInput.Length; i++)
            {
                StringInput = StringInput + "  ";
                tempTitle = StringInput;
            }
        }
        return tempTitle;
    }
}