﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
public partial class admin_登录 : System.Web.UI.Page
{
    Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if(yzm.Text==Session ["CheckCode"].ToString())
        {
            string sql = "select * from adminss where username and pwd11";
            OleDbDataReader dr = dt.row(sql);
            if (dr.Read())
            {
                Session["username"] = username.Text;
                Response.Redirect("main.aspx");
            }
            else
            {
                Response.Write("<script>alert('用户名或密码不正确')</script>");
            }
        }
            else
            {
             Response.Write("<script>alert('验证码不正确')</script>");
            }
        }
    }
