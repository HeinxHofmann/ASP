﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
public partial class admin_messagess_editor : System.Web.UI.Page
{
    Data da = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            binddata();
        }
    }
    protected void binddata()
    {
        string id = Request.QueryString["notice_id"];
        if (id != null)
        {

            string sql = "select * from noticess ";
            OleDbDataReader dr = da.row(sql);
            if (dr.Read())
            {
                TextBox1.Text = dr["notice_title"].ToString();
                TextBox2.Text = dr["notice_author"].ToString();
                content1.InnerHtml = dr["notice_contnet"].ToString();
                
            }
        }
        else
        {
            // 处理id为null的情况
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string id = Request.QueryString["notice_id"].ToString();
        string sql = "update noticess set notice_title='" + TextBox1.Text + "',messagess_author='" + TextBox2.Text + "',messagess_content='" + content1.InnerText + "' " ;

        if (da.add_delete_update(sql))
        {
            Response.Write("<script>alert('更新成功')</script>");
        }
    }
    protected void DropDownList12()
    {
        
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
}