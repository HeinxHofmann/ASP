﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
public partial class admin_messagess_admin : System.Web.UI.Page
{
    Data da = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bindtogridview1();
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }


    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bindtogridview1();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string sql = "delete from noticess where notice_id=" + GridView1.DataKeys[e.RowIndex].Value;
        if (da.add_delete_update(sql))
        {
            Response.Write("<script>alert('删除成功');window.location.href='notice_admin.aspx'</script>");
        }
    }
    protected void bindtogridview1()
    {
        string sql = "select * from noticess";
        GridView1.DataSource = da.rows(sql, "www").DefaultView;
        GridView1.DataBind();
    }
}