﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
public partial class admin_user_add : System.Web.UI.Page
{
    Data da = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string sql = "insert into noticess(notice_title,notice_author,notice_contnet) values('"+TextBox1.Text+"','"+TextBox2.Text+"','"+content1.InnerText+"')";

        if (da.add_delete_update(sql))
        { Response.Write("<script>alert('添加成功')</script>"); }

       
        
    }
   
}