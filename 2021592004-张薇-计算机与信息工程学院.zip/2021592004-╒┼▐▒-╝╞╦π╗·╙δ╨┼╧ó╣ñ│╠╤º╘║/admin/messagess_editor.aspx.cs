﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
public partial class admin_messagess_editor : System.Web.UI.Page
{
    Data da = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            binddata();
        }
    }
    protected void binddata()
    {
        string id = Request.QueryString["messagess_id"];
        if (id != null)
        {

            string sql = "select * from messagess where messagess_id=" + id;
            OleDbDataReader dr = da.row(sql);
            if (dr.Read())
            {
                TextBox1.Text = dr["messagess_title"].ToString();
                TextBox2.Text = dr["messagess_author"].ToString();
                content1.InnerHtml = dr["messagess_content"].ToString();
                DropDownList1.SelectedIndex = Convert.ToInt32(dr["column1_id"]) - 1;
                DropDownList12();
            }
        }
        else
        {
            // 处理id为null的情况
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string id = Request.QueryString["messagess_id"].ToString();
        string sql = "update messagess set messagess_title='" + TextBox1.Text + "',messagess_author='" + TextBox2.Text + "',column1_id="
            + DropDownList1.SelectedValue + ",column2_id=" + DropDownList2.SelectedValue + ",messagess_content='" + content1.InnerText + "' where messagess_id=" + id;

        if (da.add_delete_update(sql))
        {
            Response.Write("<script>alert('更新成功')</script>");
        }
    }
    protected void DropDownList12()
    {
        string sql = "select * from columnss where column1_id=" + DropDownList1.SelectedValue + "";
        DropDownList2.DataSource = da.rows(sql, "qqq").DefaultView;
        DropDownList2.DataTextField = "column2_content";
        DropDownList2.DataValueField = "column2_id";
        DropDownList2.DataBind();
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string sql = "select * from columnss where column1_id=" + DropDownList1.SelectedValue + "";
        DropDownList2.DataSource = da.rows(sql, "wqe").DefaultView;
        DropDownList2.DataTextField = "column2_content";
        DropDownList2.DataValueField = "column2_id";
        DropDownList2.DataBind();
    }
}