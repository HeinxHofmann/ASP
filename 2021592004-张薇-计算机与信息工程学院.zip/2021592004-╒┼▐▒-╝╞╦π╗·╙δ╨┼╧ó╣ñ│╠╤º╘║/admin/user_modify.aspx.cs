﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
public partial class admin_user_modify : System.Web.UI.Page
{
    Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox1.Text=Session["username"].ToString();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string sql = "update adminss set pwd11='" + TextBox2.Text + "' where username='" + TextBox1.Text + "'";
        if(TextBox2.Text==TextBox3.Text)
        {
            if (dt.add_delete_update(sql))
                Response.Write("<script>alert('修改成功')</script>");
           
        }
        else
        {
            Response.Write("<script>alert('新密码与确认密码不一致')</script>");
        }
    }
}