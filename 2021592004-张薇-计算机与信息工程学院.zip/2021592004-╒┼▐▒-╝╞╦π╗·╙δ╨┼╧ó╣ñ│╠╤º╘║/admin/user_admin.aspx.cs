﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
public partial class admin_user_admin : System.Web.UI.Page
{
    Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bindtogridview1();
        }
    }
    protected void bindtogridview1()
    {
        string sql = "select * from adminss ";
        GridView1.DataSource = dt.rows(sql, "wwwt").DefaultView;
        GridView1.DataBind();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string sql = "delete from adminss where username='"+GridView1.DataKeys [e.RowIndex].Value+"'";
        if (dt.add_delete_update(sql))
        {
            Response.Write("<script>alert('删除成功');window.location.href='user_admin.aspx'</script>");
        }
       
    }
}