﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
public partial class admin_user_add : System.Web.UI.Page
{
    Data da = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string sql = "insert into messagess(messagess_title,messagess_author,column1_id,column2_id,messagess_content) values('"+TextBox1.Text+"','"+TextBox2.Text+"',"+DropDownList1.SelectedValue+","+DropDownList2.SelectedValue+",'"+content1.InnerText+"')";

        if (da.add_delete_update(sql))
        { Response.Write("<script>alert('添加成功')</script>"); }

       
        
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string sql = "select * from columnss where column1_id="+DropDownList1.SelectedValue+"";
        DropDownList2.DataSource = da.rows(sql,"qqq").DefaultView;
        DropDownList2.DataTextField = "column2_content";
        DropDownList2.DataValueField = "column2_id";
        DropDownList2.DataBind();
    }
}