﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OleDb;
/// <summary>
///Data 的摘要说明
/// </summary>
public class Data
{
	public Data()
	{
		//
		//TODO: 在此处添加构造函数逻辑
		//
	}
    public DataTable rows(string sql,string table)
    {
        OleDbConnection conn = new OleDbConnection("provider=microsoft.ace.oledb.12.0;data source=|DataDirectory|jsj.accdb");
        OleDbCommand comm = new OleDbCommand(sql,conn);
        OleDbDataAdapter adp = new OleDbDataAdapter(comm);
        DataSet ds = new DataSet();
        adp.Fill(ds,table);
        return ds.Tables [table];

    
    }
    


    public OleDbDataReader row(string sql)
    {
        OleDbConnection conn = new OleDbConnection("provider=microsoft.ace.oledb.12.0;data source=|DataDirectory|jsj.accdb");
        OleDbCommand comm = new OleDbCommand(sql, conn);
        conn.Open();
        OleDbDataReader dr = comm.ExecuteReader();
        return dr;

    }
    public Boolean add_delete_update(string sql)
    {
        OleDbConnection conn = new OleDbConnection("provider=microsoft.ace.oledb.12.0;data source=|DataDirectory|jsj.accdb");
        OleDbCommand comm = new OleDbCommand(sql,conn);
        conn.Open();
        if(comm.ExecuteNonQuery()>0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}